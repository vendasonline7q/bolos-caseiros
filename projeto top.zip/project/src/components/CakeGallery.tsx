import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const CakeGallery = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % cakes.length);
  };
  
  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + cakes.length) % cakes.length);
  };
  
  useEffect(() => {
    // Auto slide every 5 seconds
    timerRef.current = setTimeout(nextSlide, 5000);
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [currentIndex]);

  const handleDotClick = (index: number) => {
    setCurrentIndex(index);
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = setTimeout(nextSlide, 5000);
  };
  
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-center text-brown-900">
          Galeria de Bolos Que Você Vai Aprender
        </h2>
        
        <p className="text-xl text-brown-700 text-center max-w-3xl mx-auto mb-12">
          Receitas exclusivas com técnicas simples que parecem complexas - ideais para vender em qualquer cidade
        </p>
        
        <div className="relative max-w-4xl mx-auto">
          {/* Carousel */}
          <div className="overflow-hidden rounded-2xl shadow-2xl">
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {cakes.map((cake, index) => (
                <div key={index} className="min-w-full relative">
                  <div className="aspect-[16/9] overflow-hidden">
                    <img 
                      src={cake.image} 
                      alt={cake.name} 
                      className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-1000 ease-out"
                    />
                  </div>
                  
                  {/* Badge */}
                  <div className="absolute top-4 right-4">
                    <div className="bg-gradient-to-r from-pink-500 to-pink-400 px-4 py-2 rounded-full text-white font-bold shadow-lg">
                      {cake.badge}
                    </div>
                  </div>
                  
                  {/* Caption */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent text-white p-6">
                    <h3 className="text-2xl font-display font-bold mb-2">{cake.name}</h3>
                    <p className="text-white/90">{cake.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Navigation Arrows */}
          <button 
            onClick={prevSlide}
            className="absolute top-1/2 left-4 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-900 rounded-full p-2 shadow-lg z-10"
            aria-label="Previous slide"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute top-1/2 right-4 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-900 rounded-full p-2 shadow-lg z-10"
            aria-label="Next slide"
          >
            <ChevronRight size={24} />
          </button>
          
          {/* Dots */}
          <div className="flex justify-center mt-4 space-x-2">
            {cakes.map((_, index) => (
              <button
                key={index}
                onClick={() => handleDotClick(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-pink-500' : 'bg-gray-300'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const cakes = [
  {
    name: "Bolo de Nutella com Leite Ninho",
    description: "O mais vendido da nossa comunidade, com média de R$120 por bolo de 1kg",
    image: "https://images.pexels.com/photos/6210965/pexels-photo-6210965.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    badge: "TOP VENDAS"
  },
  {
    name: "Bolo Vulcão de Chocolate",
    description: "Receita infalível que rende até 15 bolos individuais por produção",
    image: "https://images.pexels.com/photos/6210689/pexels-photo-6210689.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    badge: "FAVORITO DAS ALUNAS"
  },
  {
    name: "Bolo de Limão com Cream Cheese",
    description: "Pronto em apenas 45 minutos, ideal para iniciantes",
    image: "https://images.pexels.com/photos/4686833/pexels-photo-4686833.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    badge: "MAIS FÁCIL"
  }
];

export default CakeGallery;