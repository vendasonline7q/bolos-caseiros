import { Flame, Smartphone, DollarSign } from 'lucide-react';

const Benefits = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-brown-800 to-brown-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-16 text-center">
          Por Que Nossas Alunas Têm <span className="text-pink-400">Resultados Rápidos</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {benefits.map((benefit, index) => (
            <div 
              key={index}
              className="bg-brown-800 rounded-2xl p-8 border border-pink-500/20 shadow-xl transform hover:scale-105 transition-transform duration-300"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-pink-400 flex items-center justify-center mb-6 mx-auto">
                {benefit.icon}
              </div>
              
              <h3 className="text-2xl font-display font-bold text-center mb-4">
                {benefit.title}
              </h3>
              
              <p className="text-center text-gray-200 leading-relaxed">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const benefits = [
  {
    icon: <Flame size={32} className="text-white" />,
    title: "Receitas à Prova de Falhas",
    description: "Fórmulas testadas 37x em fornos comuns de diferentes marcas para garantir resultados consistentes."
  },
  {
    icon: <Smartphone size={32} className="text-white" />,
    title: "Área de Membros VIP",
    description: "Acesso 24h pelo celular ou computador, assista quando e onde quiser, sem pressa para aprender."
  },
  {
    icon: <DollarSign size={32} className="text-white" />,
    title: "Guia de Vendas",
    description: "Como precificar e vender seus bolos 10x mais rápido, incluindo modelos de orçamento prontos para usar."
  }
];

export default Benefits;