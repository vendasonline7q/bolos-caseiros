import { useState } from 'react';
import { ChevronDown, ChevronUp, Shield } from 'lucide-react';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  
  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };
  
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-12 text-center text-brown-900">
            Perguntas Frequentes
          </h2>
          
          <div className="space-y-4 mb-16">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className="border border-gray-200 rounded-lg overflow-hidden shadow-sm"
              >
                <button
                  className="w-full flex justify-between items-center p-5 text-left bg-white hover:bg-gray-50 focus:outline-none transition-colors"
                  onClick={() => toggleQuestion(index)}
                >
                  <span className="font-semibold text-lg text-brown-900 flex items-center">
                    <span className="text-pink-500 mr-2">❓</span>
                    {faq.question}
                  </span>
                  {openIndex === index ? (
                    <ChevronUp className="text-pink-500 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="text-pink-500 flex-shrink-0" />
                  )}
                </button>
                
                {openIndex === index && (
                  <div className="p-5 bg-gray-50 border-t border-gray-200">
                    <p className="text-brown-700">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          {/* Guarantee Box */}
          <div className="bg-gradient-to-r from-pink-500/10 to-pink-500/5 border-2 border-pink-500/30 rounded-lg p-8 mb-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 -mt-8 -mr-8 bg-pink-500/10 rounded-full blur-2xl"></div>
            
            <div className="flex flex-col md:flex-row items-center">
              <div className="mb-6 md:mb-0 md:mr-8">
                <div className="w-20 h-20 bg-pink-500 rounded-full flex items-center justify-center">
                  <Shield className="text-white" size={36} />
                </div>
              </div>
              
              <div>
                <h3 className="text-2xl font-display font-bold text-brown-900 mb-3">
                  ⚠️ RISCO ZERO: 7 Dias para Testar!
                </h3>
                <p className="text-brown-700 text-lg">
                  Se você não amar o curso, devolvemos cada centavo. Sem perguntas, sem burocracias. Basta enviar um email para suporte@bolocaseiro.com.br e devolveremos seu investimento integralmente.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-brown-900 font-semibold mb-3">
              Ainda tem dúvidas? Fale com nossa equipe:
            </p>
            <a 
              href="https://wa.me/5511999999999"
              className="inline-flex items-center text-pink-600 hover:text-pink-700 font-medium"
              target="_blank"
              rel="noopener noreferrer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              Enviar mensagem no WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

const faqs = [
  {
    question: "Preciso de experiência para fazer o curso?",
    answer: "Não! O curso foi desenvolvido para iniciantes absolutos. Ensinamos do zero, desde como escolher os ingredientes até técnicas avançadas de decoração. Você só precisa de vontade de aprender."
  },
  {
    question: "Como é o acesso ao curso?",
    answer: "O acesso é imediato após a confirmação do pagamento. Você receberá um e-mail com login e senha para acessar nossa plataforma exclusiva. O curso pode ser assistido pelo computador, tablet ou celular, 24 horas por dia, sem limite de visualizações."
  },
  {
    question: "Preciso comprar equipamentos caros?",
    answer: "Não! Todo o método foi desenvolvido para funcionar com utensílios básicos de cozinha. Ensinamos adaptações que permitem fazer bolos profissionais mesmo sem batedeira ou forno industrial."
  },
  {
    question: "Por quanto tempo terei acesso ao curso?",
    answer: "O acesso é vitalício! Uma vez que você compra, tem acesso para sempre, incluindo todas as atualizações futuras sem custo adicional."
  },
  {
    question: "Consigo realmente vender com as receitas do curso?",
    answer: "Sim! Todas as receitas foram desenvolvidas pensando na comercialização. Elas são econômicas, escalonáveis e possuem alto valor percebido. Além disso, temos um módulo completo sobre precificação e vendas."
  }
];

export default FAQ;