import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };
  
  return (
    <section className="py-20 bg-gradient-to-b from-brown-900 to-brown-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-center">
          O Que Nossas Alunas Estão Dizendo
        </h2>
        
        <p className="text-xl text-center max-w-3xl mx-auto mb-12 text-white/80">
          Histórias reais de pessoas comuns que transformaram sua vida com o Curso Bolos Caseiros 2.0
        </p>
        
        <div className="relative max-w-5xl mx-auto">
          {/* Testimonial Carousel */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="min-w-full px-4">
                  <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div className="grid grid-cols-1 md:grid-cols-2">
                      {/* Testimonial Content */}
                      <div className="p-8 md:p-10 flex flex-col justify-between">
                        <div>
                          <div className="flex mb-3">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="fill-yellow-400 text-yellow-400" size={20} />
                            ))}
                          </div>
                          
                          <h3 className="text-2xl font-semibold text-brown-900 mb-2">
                            {testimonial.title}
                          </h3>
                          
                          <p className="text-brown-700 mb-6 italic">
                            "{testimonial.quote}"
                          </p>
                          
                          <div className="bg-pink-100 p-4 rounded-lg border-l-4 border-pink-500 mb-6">
                            <p className="text-brown-800 font-medium">
                              {testimonial.result}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                            <img 
                              src={testimonial.avatar} 
                              alt={testimonial.name} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <p className="font-semibold text-brown-900">{testimonial.name}</p>
                            <p className="text-brown-600 text-sm">{testimonial.location}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Before/After Image */}
                      <div className="relative">
                        <img 
                          src={testimonial.image} 
                          alt={`${testimonial.name} result`} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-4 left-4 bg-pink-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                          Resultado Real
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Navigation Arrows */}
          <button 
            onClick={prevTestimonial}
            className="absolute top-1/2 left-0 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-900 rounded-full p-2 shadow-lg z-10"
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={nextTestimonial}
            className="absolute top-1/2 right-0 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-900 rounded-full p-2 shadow-lg z-10"
            aria-label="Next testimonial"
          >
            <ChevronRight size={24} />
          </button>
        </div>
        
        {/* Satisfaction Seal */}
        <div className="mt-16 text-center">
          <div className="inline-block bg-gradient-to-r from-pink-500/20 to-pink-500/10 rounded-lg border border-pink-500/30 px-8 py-4">
            <div className="text-pink-200 font-display text-2xl font-bold mb-1">
              🏆 97% de Satisfação
            </div>
            <p className="text-white/80">
              Baseado em 1.203 avaliações verificadas
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const testimonials = [
  {
    name: "Maria Silva",
    location: "Porto Alegre, RS",
    avatar: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    title: "De iniciante a confeiteira em 2 semanas",
    quote: "Nunca tinha feito um bolo decente na vida. Comprei o curso achando que seria mais um desperdício de dinheiro...",
    result: "Comprei como aposta e em 1 semana já vendi R$240 em bolos de pote! Nem acredito que consegui!",
    image: "https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Renata Oliveira",
    location: "Vitória, ES",
    avatar: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    title: "De desempregada a microempreendedora",
    quote: "Perdi meu emprego na pandemia e estava desesperada. Uma amiga me indicou o curso, e mesmo sem acreditar muito...",
    result: "Antes: zero vendas. Depois: encomendas toda semana! Agora tenho renda fixa maior que meu antigo salário.",
    image: "https://images.pexels.com/photos/1721932/pexels-photo-1721932.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  },
  {
    name: "Camila Rodrigues",
    location: "Recife, PE",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    title: "De hobby a negócio lucrativo",
    quote: "Fazia bolos apenas para a família, mas sempre comentavam que eu deveria vender. Não tinha confiança até encontrar o método...",
    result: "Já vendi mais de 50 bolos em 2 meses! O método de precificação me ajudou a cobrar o valor justo sem medo.",
    image: "https://images.pexels.com/photos/1854652/pexels-photo-1854652.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
  }
];

export default Testimonials;