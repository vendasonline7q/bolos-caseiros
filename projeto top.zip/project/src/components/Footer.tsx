import { AlertTriangle } from 'lucide-react';
import CTAButton from './CTAButton';

interface FooterProps {
  remainingTime: {
    hours: number;
    minutes: number;
    seconds: number;
  };
}

const Footer = ({ remainingTime }: FooterProps) => {
  return (
    <section className="relative bg-gradient-to-b from-brown-800 to-brown-900 pt-16 pb-8">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-y-0 left-0 w-1/3 bg-pink-500/10"></div>
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-pink-500/5 rounded-bl-full"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <div className="inline-flex items-center bg-red-500/80 text-white px-6 py-3 rounded-full mb-8">
            <AlertTriangle className="mr-2" size={24} />
            <span className="font-bold text-lg">Última Chance! Preço sobe em:</span>
            <div className="ml-3 font-mono bg-white/20 px-2 py-1 rounded">
              {String(remainingTime.hours).padStart(2, '0')}:{String(remainingTime.minutes).padStart(2, '0')}:{String(remainingTime.seconds).padStart(2, '0')}
            </div>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-8">
            Transforme Sua Paixão por Bolos em um Negócio Lucrativo Hoje Mesmo!
          </h2>
          
          <p className="text-xl mb-10 text-white/90">
            Junte-se às mais de 3.700 alunas que estão faturando com confeitaria caseira usando nosso método exclusivo
          </p>
          
          <div className="mb-16">
            <CTAButton />
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <p className="text-white/60 text-sm">
                © 2024 Curso Bolos Caseiros. Todos os direitos reservados.
              </p>
            </div>
            
            <div className="flex space-x-5">
              <a href="#" className="text-white/60 hover:text-white/90 text-sm">
                Política de Privacidade
              </a>
              <a href="#" className="text-white/60 hover:text-white/90 text-sm">
                Termos de Uso
              </a>
              <a href="mailto:suporte@bolocaseiro.com.br" className="text-white/60 hover:text-white/90 text-sm">
                Dúvidas?
              </a>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-white/50 text-xs">
              Este site não é afiliado ao Facebook, Google ou qualquer entidade do Facebook. Uma vez que sair do Facebook, a responsabilidade não é deles e sim do nosso site. Fazemos todos os esforços para indicar claramente e mostrar todas as provas do produto e usamos resultados reais.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Footer;