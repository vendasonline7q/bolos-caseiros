import { Calendar, Lock, Zap, CreditCard } from 'lucide-react';

const TrustBadges = () => {
  return (
    <section className="bg-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-4 md:gap-8 lg:gap-12">
          <div className="flex items-center text-brown-800">
            <Calendar className="mr-2 text-pink-500" size={24} />
            <span className="font-semibold">7 Dias de Garantia</span>
          </div>
          
          <div className="flex items-center text-brown-800">
            <Lock className="mr-2 text-pink-500" size={24} />
            <span className="font-semibold">Pagamento 100% Seguro</span>
          </div>
          
          <div className="flex flex-wrap justify-center gap-2 ml-2">
            <img src="https://cdn-icons-png.flaticon.com/128/349/349221.png" alt="Visa" className="h-6" />
            <img src="https://cdn-icons-png.flaticon.com/128/349/349228.png" alt="Mastercard" className="h-6" />
            <img src="https://cdn-icons-png.flaticon.com/128/349/349230.png" alt="PayPal" className="h-6" />
            <img src="https://cdn-icons-png.flaticon.com/128/349/349247.png" alt="Amex" className="h-6" />
          </div>
          
          <div className="flex items-center text-brown-800">
            <Zap className="mr-2 text-pink-500" size={24} />
            <span className="font-semibold">Acesso Imediato</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustBadges;