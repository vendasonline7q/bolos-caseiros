import { X, Check } from 'lucide-react';

const Problem = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-brown-900 to-brown-800">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-12 text-center">
            Você Já Passou por Isso?
          </h2>
          
          <div className="space-y-6 mb-12">
            {problemItems.map((item, index) => (
              <div 
                key={index} 
                className="flex items-start bg-brown-800/50 p-5 rounded-lg border-l-4 border-red-500 transform hover:-translate-y-1 transition-transform duration-300"
              >
                <div className="flex-shrink-0 p-2 bg-red-500 rounded-full mr-4">
                  <X className="text-white" size={20} />
                </div>
                <p className="text-xl">{item}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-gradient-to-r from-pink-500/20 to-pink-500/10 p-8 rounded-lg border border-pink-500/30">
            <h3 className="text-2xl font-display font-bold mb-6 text-pink-200">
              A Solução Que Você Precisa
            </h3>
            
            <div className="space-y-4">
              {solutionItems.map((item, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 p-1 bg-green-500 rounded-full mr-3">
                    <Check className="text-white" size={18} />
                  </div>
                  <p className="text-lg">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const problemItems = [
  "Receitas que nunca dão certo no seu forno",
  "Gastar fortunas em ingredientes caros",
  "Bolos que desmancham na hora de vender",
  "Medo de fazer orçamentos e perder clientes"
];

const solutionItems = [
  "Método Aprovado por Confeiteiras Profissionais",
  "Adaptações para Fogão Doméstico (sem equipamentos caros)",
  "Receitas econômicas com alto valor percebido",
  "Fórmulas de precificação para nunca vender barato"
];

export default Problem;