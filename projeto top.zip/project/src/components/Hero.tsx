import { Timer } from 'lucide-react';
import CTAButton from './CTAButton';

interface HeroProps {
  remainingTime: {
    hours: number;
    minutes: number;
    seconds: number;
  };
}

const Hero = ({ remainingTime }: HeroProps) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-b from-brown-900 to-brown-800 overflow-hidden">
      {/* Background overlay with cake image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-fixed opacity-40" 
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/1854652/pexels-photo-1854652.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')",
          backgroundPosition: "center"
        }}
      />
      
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-brown-900 opacity-60"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6 inline-block px-5 py-2 bg-pink-500 bg-opacity-90 rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300">
            <span className="text-white font-bold text-lg">🔥 MÉTODO EXCLUSIVO</span>
          </div>
          
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-display font-bold mb-6 leading-tight">
            Revelado: O Método 6 Passos para Fazer Bolos de Confeitaria em Casa Usando Apenas Utensílios Básicos!
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto leading-relaxed">
            Descubra como <span className="font-bold text-pink-300">+3.728 alunas comuns</span> estão faturando <span className="font-bold text-pink-300">R$800+/mês</span> vendendo bolos com receitas testadas em fornos de padaria caseira!
          </p>
          
          <div className="mb-12">
            <CTAButton />
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center items-center gap-6 text-lg">
            <div className="flex items-center bg-brown-800 px-5 py-3 rounded-lg border border-pink-500/30">
              <Timer className="text-pink-400 mr-2" size={24} />
              <span className="mr-2 text-white/90">OFERTA VÁLIDA POR:</span>
              <div className="font-mono bg-pink-600 text-white px-2 py-1 rounded">
                {String(remainingTime.hours).padStart(2, '0')}:{String(remainingTime.minutes).padStart(2, '0')}:{String(remainingTime.seconds).padStart(2, '0')}
              </div>
            </div>
            
            <div className="bg-brown-800 px-5 py-3 rounded-lg border border-pink-500/30">
              <span className="text-pink-400 font-bold">ÚLTIMAS 7 VAGAS!</span>
              <span className="ml-2 text-white/90">(Lotamos 93% hoje)</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;