import { ChevronRight } from 'lucide-react';

const CTAButton = () => {
  return (
    <a
      href="https://pay.cakto.com.br/f855w6o_379172"
      className="inline-block bg-red-600 hover:bg-red-700 text-white text-xl md:text-2xl font-bold px-8 py-4 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out"
      target="_blank"
      rel="noopener noreferrer"
    >
      <div className="flex items-center justify-center">
        <span className="mr-2">👉</span>
        <span>QUERO APRENDER AGORA!</span>
        <ChevronRight className="ml-2" size={24} />
      </div>
      <div className="text-sm font-normal mt-1 opacity-90">
        (Acesso Imediato)
      </div>
    </a>
  );
};

export default CTAButton;