import { CheckCircle, Tablet, Smartphone } from 'lucide-react';

const CourseDemo = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            {/* Course Mockup */}
            <div className="md:w-1/2 mb-12 md:mb-0">
              <div className="relative">
                {/* Tablet Mockup */}
                <div className="relative mx-auto w-4/5 transform perspective rotate-y-3 rotate-z-2 shadow-2xl rounded-xl overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-tr from-brown-800/90 to-brown-800/60 mix-blend-multiply rounded-xl"></div>
                  <img 
                    src="https://images.pexels.com/photos/6210764/pexels-photo-6210764.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                    alt="Curso Bolos Caseiros 2.0" 
                    className="w-full rounded-xl"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                    <div className="flex items-center">
                      <Tablet className="text-white mr-2" size={20} />
                      <span className="text-white font-semibold">Módulo 3: Bases Perfeitas</span>
                    </div>
                  </div>
                </div>
                
                {/* Phone Mockup */}
                <div className="absolute -bottom-10 -right-5 w-1/3 bg-brown-900 rounded-xl overflow-hidden shadow-xl border-4 border-white">
                  <div className="relative pb-[178%]"> {/* 16:9 aspect ratio */}
                    <img 
                      src="https://images.pexels.com/photos/6210876/pexels-photo-6210876.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                      alt="Bolo Vulcão" 
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black to-transparent">
                      <div className="flex items-center">
                        <Smartphone className="text-white mr-1" size={14} />
                        <span className="text-white text-xs font-semibold">Bolo Vulcão (17 min)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Course Details */}
            <div className="md:w-1/2 md:pl-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-8 text-brown-900">
                O Que Você Vai Aprender No Curso
              </h2>
              
              <div className="space-y-5 mb-8">
                {courseModules.map((module, index) => (
                  <div key={index} className="flex">
                    <CheckCircle className="flex-shrink-0 text-pink-500 mr-3 mt-1" size={22} />
                    <div>
                      <h4 className="text-xl font-semibold text-brown-800">{module.title}</h4>
                      <p className="text-brown-700">{module.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Bonus Box */}
              <div className="bg-pink-100 border-2 border-pink-300 rounded-lg p-6 transform hover:-rotate-1 transition-transform duration-300">
                <h3 className="text-2xl font-display font-bold text-brown-900 mb-3">
                  ✅ Bônus Exclusivo
                </h3>
                <p className="text-brown-800 text-lg mb-2">
                  <span className="font-semibold">Apostila Digital com 50 Receitas Extras!</span>
                </p>
                <p className="text-brown-700">
                  Inclui receitas de bolos gourmets que vendem por até R$120 cada. Receitas exclusivas não encontradas no YouTube!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const courseModules = [
  {
    title: "Módulo 1: Bases Perfeitas",
    description: "Aprenda as bases fundamentais para massas que nunca falham, mesmo em fornos domésticos."
  },
  {
    title: "Módulo 2: Recheios de Sucesso",
    description: "Técnicas para recheios estáveis e que não escorrem, ideais para comercialização."
  },
  {
    title: "Módulo 3: Coberturas Profissionais",
    description: "Ganache perfeito, coberturas espelhadas e técnicas de decoração sem equipamentos caros."
  },
  {
    title: "Módulo 4: Bolos que Vendem",
    description: "Como precificar, embalar e vender seus bolos para maximizar lucros."
  }
];

export default CourseDemo;