import { useState, useEffect } from 'react';
import Hero from './components/Hero';
import TrustBadges from './components/TrustBadges';
import Problem from './components/Problem';
import CourseDemo from './components/CourseDemo';
import Benefits from './components/Benefits';
import CakeGallery from './components/CakeGallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import './styles/fonts.css';

function App() {
  const [remainingTime, setRemainingTime] = useState({
    hours: 0,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingTime(prev => {
        const newSeconds = prev.seconds - 1;
        
        if (newSeconds < 0) {
          const newMinutes = prev.minutes - 1;
          
          if (newMinutes < 0) {
            const newHours = prev.hours - 1;
            
            if (newHours < 0) {
              // Timer expired
              return { hours: 0, minutes: 0, seconds: 0 };
            }
            
            return { hours: newHours, minutes: 59, seconds: 59 };
          }
          
          return { ...prev, minutes: newMinutes, seconds: 59 };
        }
        
        return { ...prev, seconds: newSeconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="font-body text-white">
      <Hero remainingTime={remainingTime} />
      <TrustBadges />
      <Problem />
      <CourseDemo />
      <Benefits />
      <CakeGallery />
      <Testimonials />
      <FAQ />
      <Footer remainingTime={remainingTime} />
    </div>
  );
}

export default App;