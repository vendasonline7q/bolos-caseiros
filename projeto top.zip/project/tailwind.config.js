/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brown: {
          50: '#faf5f1',
          100: '#f5e9df',
          200: '#e8d1bc',
          300: '#d9b594',
          400: '#c89870',
          500: '#b97d50',
          600: '#9c6540',
          700: '#7d5035',
          800: '#6B4423',
          900: '#432c1b',
        },
        pink: {
          50: '#fff0f4',
          100: '#ffe1e9',
          200: '#ffc8d9',
          300: '#ffafc9',
          400: '#ff8eb3',
          500: '#FFB6C1', // Light pink (primary)
          600: '#ff3d82',
          700: '#f01d6d',
          800: '#d31b63',
          900: '#b01a58',
        },
      },
      fontFamily: {
        'display': ['"Playfair Display"', 'serif'],
        'body': ['Montserrat', 'sans-serif'],
      },
      boxShadow: {
        'outline-pink': '0 0 0 3px rgba(255, 182, 193, 0.5)',
      },
      animation: {
        'bounce-slow': 'bounce 2s infinite',
      },
    },
  },
  plugins: [],
};